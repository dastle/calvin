/// @file
/// @author Alexander Thomson (thomson@cs.yale.edu)
/// @version 0.1
/// @since 5 April 2012
///
/// @section DESCRIPTION
///
/// Connection unit tests.
///
/// @TODO(alex): Write some tests spanning multiple physical machines.
/// @TODO(alex): All tests are commented out! Add them back in plz kthks.

#include "connection/connection.h"
#include "common/configuration.h"
#include "common/utils.h"
#include "connection/caravan.h"
#include <unistd.h>
#define GetCurrentDir getcwd

#include <gtest/gtest.h>
#include <glog/logging.h>

using caravan::ClusterManager;
using caravan::Machine;
using leveldb::Slice;

void* thread_listen(void* arg) {
  Machine *machine = (Machine *)arg;
  machine->Listen();
}


TEST(NULL, ShouldConnect) {

  Machine *machine0 = new Machine(0, 50000);
  Machine *machine1 = new Machine(1, 50001);
  
  machine0->AddMachine(1, "127.0.0.1", 50001);
  machine1->AddMachine(0, "127.0.0.1", 50000);
  pthread_t t1;
  pthread_create(&t1, NULL, &thread_listen, machine0);
  machine1->Connect(0);
  pthread_join(t1, NULL);

  delete machine0;
  delete machine1;

}


// Tests that sockets are reusable
TEST(NULL, ShouldConnectMultipleTimes) {
  Machine *machine0 = new Machine(0, 50000);
  Machine *machine1 = new Machine(1, 50001);
  
  machine0->AddMachine(1, "127.0.0.1", 50001);
  machine1->AddMachine(0, "127.0.0.1", 50000);
  pthread_t t1;
  pthread_create(&t1, NULL, &thread_listen, machine0);
  machine1->Connect(0);
  pthread_join(t1, NULL);

  delete machine0;
  delete machine1;


  machine0 = new Machine(0, 50000);
  machine1 = new Machine(1, 50001);
  
  machine0->AddMachine(1, "127.0.0.1", 50001);
  machine1->AddMachine(0, "127.0.0.1", 50000);
  pthread_create(&t1, NULL, &thread_listen, machine0);
  machine1->Connect(0);
  pthread_join(t1, NULL);

  delete machine0;
  delete machine1;

}


TEST(NULL, SendMessageOneNode) {

  Machine *machine0 = new Machine(0, 50000);
  Machine *machine1 = new Machine(1, 50001);
  
  machine0->AddMachine(1, "127.0.0.1", 50001);
  machine1->AddMachine(0, "127.0.0.1", 50000);
  pthread_t t1;
  pthread_create(&t1, NULL, &thread_listen, machine0);
  machine1->Connect(0);
  pthread_join(t1, NULL);
  Slice msg("Hello world!");
  machine1->SendMessage(0, &msg);
  caravan::Message *receivedMsg = machine0->ReceiveMessage();
  EXPECT_STREQ("Hello world!", receivedMsg->data());

  delete machine0;
  delete machine1;
  delete receivedMsg;

}

int main(int argc, char** argv) {
  google::InitGoogleLogging(argv[0]);
  ::testing::InitGoogleTest(&argc, argv);
  return RUN_ALL_TESTS();
}

