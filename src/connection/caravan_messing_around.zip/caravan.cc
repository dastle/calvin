#include "connection/caravan.h"
#include <errno.h>

caravan::ClusterManager::ClusterManager() {
}


caravan::Machine::Machine(MachineID id, unsigned int port) {
  port_ = port;
  struct sockaddr_in serverEndPoint;
  inSocketHandle_ = socket(PF_INET, SOCK_STREAM, IPPROTO_TCP);
  if(-1 == inSocketHandle_)
  {
    perror("can not create socket");
  }

  memset(&serverEndPoint, 0, sizeof(serverEndPoint));

  serverEndPoint.sin_family = AF_INET;
  serverEndPoint.sin_port = htons(port);
  serverEndPoint.sin_addr.s_addr = INADDR_ANY;
  if(-1 == bind(inSocketHandle_,(struct sockaddr *)&serverEndPoint, sizeof(serverEndPoint)))
  {
    printf("error bind failed");
    close(inSocketHandle_);
  }

  // Make socket reusable so that if a socket if this address is closed and reopened
  // in the same process, no errors occur
  int on = 1;
  if (setsockopt(inSocketHandle_, SOL_SOCKET,  SO_REUSEADDR, (char *)&on, sizeof(on)) < 0) {
    perror("setsockopt() failed");
  }

  if(-1 == listen(inSocketHandle_, 10))
  {
    printf("error listen failed");
    close(inSocketHandle_);
  }
}

caravan::Machine::~Machine() {
  // Free sockets
  for ( std::map< MachineID, Socket * >::const_iterator iter = sockets_out_.begin(); iter != sockets_out_.end(); ++iter ) {

    free(iter->second->IPAddress);

    if (iter->second->Connected) {
      // Make closing the socket do a hard disconnect FOR NOW
      // TODO: Make disconnects graceful
      linger lingerOption;
      lingerOption.l_onoff = 1;
      lingerOption.l_linger = 0;
      if (setsockopt(iter->second->Handle, SOL_SOCKET,  SO_LINGER, (char *)&lingerOption, sizeof(linger)) < 0) {
        perror("setsockopt() failed linger on iterator");
      }
    }
     

    close(iter->second->Handle);
    free(iter->second);
  }
  linger lingerOption;
  lingerOption.l_onoff = 1;
  lingerOption.l_linger = 0;
  // Make closing the socket do a hard disconnect FOR NOW
  // TODO: Make disconnects graceful
  if (setsockopt(inSocketHandle_, SOL_SOCKET,  SO_LINGER, (char *)&lingerOption, sizeof(linger)) < 0) {
    perror("setsockopt() failed");
  }
   
  close(inSocketHandle_);
}

void caravan::Machine::AddMachine(MachineID otherID, char *ipAddress, unsigned int port) {

  Socket *socketInfo = new Socket();
  memset(socketInfo, 0, sizeof(Socket));
  socketInfo->IPAddress = (char *)malloc(strlen(ipAddress));
  strcpy(socketInfo->IPAddress, ipAddress);

  socketInfo->RemoteEndPoint.sin_family = AF_INET;
  socketInfo->RemoteEndPoint.sin_port = htons(port);
  int errorCode = inet_pton(AF_INET, ipAddress, &socketInfo->RemoteEndPoint.sin_addr);
  if (0 > errorCode)
  {
    perror("error: AF_INET is not a valid address family");
  }
  else if (0 == errorCode)
  {
    perror("A valid IP Address was not passed in");
  }
 
  sockets_out_[otherID] = socketInfo;
}

void caravan::Machine::SendMessage(MachineID destination, const Slice *message) {
  int outSocket = sockets_out_[destination]->Handle;
  send(outSocket, message->data(), message->size(), 0);
}

void caravan::Machine::Listen() {
  int result = listen(inSocketHandle_, 10);
  if (result != 0) {
    perror("Listen failed");
  }
 
  int newSocket = accept(inSocketHandle_, NULL, NULL);
  if (newSocket <= 0) {
    perror("No new socket accepted");
  } else {
    // Accept incoming socket
    // Make closing the socket do a hard disconnect FOR NOW
    // TODO: Make disconnects graceful
    linger lingerOption;
    lingerOption.l_onoff = 1;
    lingerOption.l_linger = 0;
    if (setsockopt(inSocketHandle_, SOL_SOCKET,  SO_LINGER, (char *)&lingerOption, sizeof(linger)) < 0) {
      perror("setsockopt() linger failed on listen");
    }
    close(inSocketHandle_);

    inSocketHandle_ = newSocket;
    int on = 1;
    if (setsockopt(inSocketHandle_, SOL_SOCKET,  SO_REUSEADDR, (char *)&on, sizeof(on)) < 0) {
      perror("setsockopt() failed");
    }



  
  }
}

caravan::Message *caravan::Machine::ReceiveMessage() {

 
  char *buf = (char *)malloc(255);
  memset(buf, 0, 255);
  
  int result = recv(inSocketHandle_, buf, 255, 0);
  if (result < 0) {
    perror("Error occurred in ReceiveMessage() ");
  }
  Message *msg = new Message(buf, 255);
  return msg;


}

bool caravan::Machine::Connect(MachineID machineID) {
  Socket *outSocket = sockets_out_[machineID];
  if (outSocket->Connected) {
    perror("Socket is already connected");
    return false;
  }

  outSocket->Handle = socket(PF_INET, SOCK_STREAM, IPPROTO_TCP);
  int on = 1;
  if (setsockopt(outSocket->Handle, SOL_SOCKET,  SO_REUSEADDR, (char *)&on, sizeof(on)) < 0) {
    perror("setsockopt() failed");
  }


  if (-1 == outSocket->Handle)
  {
    perror("cannot create socket");
    return false;
  }

  if (-1 == connect(outSocket->Handle, (struct sockaddr *)&outSocket->RemoteEndPoint, sizeof(outSocket->RemoteEndPoint)))
  {
    perror("connect failed");
    close(outSocket->Handle);
    return false;
  }
  return true;
}


